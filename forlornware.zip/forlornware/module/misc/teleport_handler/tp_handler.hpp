#include "iostream"
#include "Windows.h"

#include "roblox/context_manager/context_manager.hpp"
#include "roblox/task_scheduler/task_scheduler.hpp"
#include "misc/globals.hpp"

#include "thread"

class teleport_handler
{
public:
	static void initialize();
};