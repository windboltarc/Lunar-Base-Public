#include "script_library.hpp"

int identifyexecutor(lua_State* L)
{
	lua_pushstring(L, "ForlornWare");
	lua_pushstring(L, "1.0.0");
	return 2;
}

int getgenv(lua_State* L)
{
	lua_pushvalue(L, LUA_ENVIRONINDEX);
	return 1;
}

std::string read_bytecode(uintptr_t addr) {
	auto str = addr + 0x10;
	auto len = *(size_t*)(str + 0x10);
	auto data = *(size_t*)(str + 0x18) > 0xf ? *(uintptr_t*) (str) : str;
	return std::string((char*)(data), len);
}

void script_library::initialize(lua_State* L)
{
	register_env_functions(L,
		{
			{"identifyexecutor", identifyexecutor},
			{"getgenv", getgenv},
			{nullptr, nullptr}
		});
}