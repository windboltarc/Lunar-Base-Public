#pragma once
#include "../../environment.hpp"

class script_library
{
public:
	static void initialize(lua_State* L);
};