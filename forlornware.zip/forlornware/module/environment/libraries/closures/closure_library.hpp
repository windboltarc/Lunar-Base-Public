#pragma once
#include "../../environment.hpp"

class closure_library
{
public:
	static void initialize(lua_State* L);
};