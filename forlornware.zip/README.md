# ForlornWare

ForlornWare is a clean and lightweight executor base made for Roblox.  
It is designed to be reliable, minimal, and easy to extend.

## Features

- Full Luau execution
- Level 8 environment support
- Built-in teleport handler
- Simple modern UI layout

ForlornWare is intended for users who want a solid foundation for custom exploit development without unnecessary complexity.
